# --- 套件 ---
library(tidyverse)
library(tidymodels)
library(themis)   # SMOTE
library(vip)
library(knitr)
library(kableExtra)
set.seed(123)

# --- 讀取資料 ---
df_raw <- read_csv("train.csv")

# 把所有類別型欄位轉換成 factor
df_raw <- df_raw %>%
  mutate(across(where(is.character), as.factor))
# 應變數：Loan_Status (Y/N)，轉成 factor
#df_raw <- df_raw %>%
  #mutate(Loan_Status = factor(Loan_Status, levels = c("N","Y")))

# 確認結果
str(df_raw)
summary(df_raw)

target <- "Loan_Status"

# --- 訓練 / 測試切分 ---
set.seed(123)
split <- initial_split(df_raw, prop = 0.8, strata = !!sym(target))
train_df <- training(split)
test_df  <- testing(split)

# --- 配方（前處理 + SMOTE）---
rec <- recipe(as.formula(paste(target, "~ .")), data = train_df) %>%
  step_string2factor(all_nominal_predictors()) %>%
  step_novel(all_nominal_predictors()) %>%
  step_other(all_nominal_predictors(), threshold = 0.01) %>%
  step_dummy(all_nominal_predictors()) %>%
  step_impute_median(all_numeric_predictors()) %>%
  step_normalize(all_numeric_predictors()) %>%
  step_corr(all_numeric_predictors(), threshold = 0.95) %>%
  step_smote(all_outcomes(), neighbors = 5)

# --- LASSO Logistic Regression ---
lasso_spec <- logistic_reg(
  penalty = tune(),
  mixture = 1
) %>% set_engine("glmnet") %>% set_mode("classification")

wf <- workflow() %>% add_model(lasso_spec) %>% add_recipe(rec)

# --- 五摺交叉驗證 ---
cv_folds <- vfold_cv(train_df, v = 5, strata = !!sym(target))
grid <- grid_regular(penalty(), levels = 40)
metrics_set <- metric_set(roc_auc, accuracy, sens, spec, f_meas)

tuned <- tune_grid(
  wf,
  resamples = cv_folds,
  grid = grid,
  metrics = metrics_set,
  control = control_grid(save_pred = TRUE)
)

best <- select_best(tuned, metric = "roc_auc")
final_wf <- finalize_workflow(wf, best)
final_fit <- fit(final_wf, data = train_df)

# --- 測試集預測 ---
test_probs <- predict(final_fit, test_df, type = "prob") %>%
  bind_cols(test_df %>% select(!!sym(target)))

roc_obj <- roc_curve(test_probs, truth = !!sym(target), .pred_Y)
pr_obj  <- pr_curve(test_probs, truth = !!sym(target), .pred_Y)

# --- 門檻計算 ---
youden_thresh <- roc_obj %>% mutate(youden = sensitivity + specificity - 1) %>%
  arrange(desc(youden)) %>% slice(1) %>% pull(.threshold)

f1_scores <- pr_obj %>% mutate(f1 = 2 * (precision * recall) / (precision + recall)) %>%
  filter(!is.na(f1))
f1_thresh <- f1_scores %>% arrange(desc(f1)) %>% slice(1) %>% pull(.threshold)

pr_balance_thresh <- pr_obj %>% mutate(diff = abs(precision - recall)) %>%
  arrange(diff) %>% slice(1) %>% pull(.threshold)

cost_thresh <- roc_obj %>%
  mutate(FN_cost = (1 - sensitivity) * 10,
         FP_cost = (1 - specificity) * 1,
         total_cost = FN_cost + FP_cost) %>%
  arrange(total_cost) %>% slice(1) %>% pull(.threshold)

fixed_thresh <- 0.5

thresholds <- tibble(
  Method = c("Youden Index", "Max F1", "PR Balance", "Cost-sensitive", "Fixed 0.5"),
  Threshold = c(youden_thresh, f1_thresh, pr_balance_thresh, cost_thresh, fixed_thresh)
)
print(thresholds)

# --- 混淆矩陣 ---
cm_results <- list()
for (i in 1:nrow(thresholds)) {
  method_name <- thresholds$Method[i]
  thres <- thresholds$Threshold[i]
  pred_df <- test_probs %>%
    mutate(.pred_class = factor(if_else(.pred_Y >= thres, "Y", "N"),
                                levels = levels(test_df[[target]])))
  cm <- conf_mat(pred_df, truth = !!sym(target), estimate = .pred_class)
  cat("\n=============================\n")
  cat("Method:", method_name, "\nThreshold:", thres, "\n")
  print(cm$table)
  cm_results[[method_name]] <- cm
}

# --- 建立一個 tibble 來存放各 threshold 的效能 ---
threshold_metrics <- tibble()

for (i in 1:nrow(thresholds)) {
  method_name <- thresholds$Method[i]
  thres <- thresholds$Threshold[i]
  
  pred_df <- test_probs %>%
    mutate(.pred_class = factor(if_else(.pred_Y >= thres, "Y", "N"),
                                levels = levels(test_df[[target]])))
  
  # 計算 confusion matrix
  cm <- conf_mat(pred_df, truth = !!sym(target), estimate = .pred_class)
  
  # 計算各種效能指標
  perf <- metrics_set(pred_df, truth = !!sym(target), 
                      estimate = .pred_class, .pred_Y)
  
  # 加上 method 名稱與 threshold
  perf <- perf %>%
    select(.metric, .estimate) %>%
    pivot_wider(names_from = .metric, values_from = .estimate) %>%
    mutate(Method = method_name,
           Threshold = round(thres, 4))
  
  # 存到總表
  threshold_metrics <- bind_rows(threshold_metrics, perf)
}

# --- 輸出表格 ---
threshold_metrics %>%
  select(Method, Threshold, roc_auc, accuracy, sens, spec, f_meas) %>%
  mutate(across(where(is.numeric), ~ round(.x, 3))) %>%
  kable("html", caption = "不同 Threshold 下的效能比較") %>%
  kable_styling(full_width = FALSE, bootstrap_options = c("striped", "hover", "condensed"))


# --- 指定要使用的 Method ---
chosen_method <- "Cost-sensitive"   # 可以改成 "Max F1"、"PR Balance"、"Cost-sensitive"、"Fixed 0.5"

# 找出對應門檻
best_thresh <- thresholds %>%
  filter(Method == chosen_method) %>%
  pull(Threshold)

# 依指定 Method 門檻進行分類
test_pred <- test_probs %>%
  mutate(.pred_class = factor(if_else(.pred_Y >= best_thresh, "Y", "N"),
                              levels = levels(test_df[[target]])))

# 輸出效能指標
perf <- metrics_set(test_pred, truth = !!sym(target), estimate = .pred_class, .pred_Y)

cat("\n=============================\n")
cat("使用 Method:", chosen_method, "\nThreshold:", round(best_thresh,4), "\n")
print(perf)

# --- 特徵重要性 ---
glmnet_fit <- extract_fit_engine(final_fit)
coefs <- coef(glmnet_fit, s = best$penalty) %>% as.matrix() %>% as.data.frame()
coefs$feature <- rownames(coefs)
colnames(coefs)[1] <- "coef"

imp_features <- coefs %>%
  filter(coef != 0, feature != "(Intercept)") %>%
  arrange(desc(abs(coef)))

top_features <- imp_features %>% slice_max(order_by = abs(coef), n = 10)

top_features %>%
  mutate(coef = round(coef, 3)) %>%
  kable("html", caption = "Loan_Status 預測模型 - 重要特徵") %>%
  kable_styling(full_width = FALSE, bootstrap_options = c("striped", "hover"))

ggplot(top_features, aes(x = reorder(feature, abs(coef)), y = coef, fill = coef > 0)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +
  labs(title = "Loan_Status 預測模型 - 重要特徵 Top 10",
       x = "特徵", y = "LASSO 迴歸係數") +
  scale_fill_manual(values = c("TRUE" = "steelblue", "FALSE" = "tomato")) +
  theme_minimal(base_size = 14)

ggsave("危機預測LASSO模型 - 重要特徵前 20 名.png", plot, width = 8, height = 6, dpi = 300)

# =========================
# 12) 存檔 (供 API 使用)
# =========================
model_bundle <- list(
  workflow   = final_fit,          # 已訓練好的 workflow
  threshold  = best_thresh,        # 選定的門檻 (例如 Cost-sensitive)
  method     = chosen_method,      # 使用的 Method 名稱
  trained_levels = list(
    outcome_levels = levels(train_df[[target]]) # 記錄因變數 levels (N / Y)
  ),
  timestamp = Sys.time()           # 存檔時間
)

saveRDS(model_bundle, file = "crisis_model_bundle.rds")
message("Saved: crisis_model_bundle.rds")
